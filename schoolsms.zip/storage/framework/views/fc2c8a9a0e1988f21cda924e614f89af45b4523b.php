<?php $__env->startSection('content'); ?>

<h1>Student Attendance</h1>
<p>Summary of SMS sent: <?php echo e($sentmsgnum); ?> </p>

<p></p>
<p></p>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>