<?php $__env->startSection('content'); ?>

<h1>SMS Usage</h1>
<p>Summary of SMS sent: <?php echo e($sentmsgnum); ?> </p>
<p>SMS Balance</p>
<p>SMS Usage per day</p>
<p></p>
<p></p>
<p></p>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>