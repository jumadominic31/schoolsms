<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class MsgTemplate extends Model
{
    //
}
