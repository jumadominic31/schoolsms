<?php $__env->startSection('content'); ?>

<h1>School Details</h1>

<table class="table table-striped" >
    <tr>
    	<td>School Name</td>
    	<td><?php echo e($schooldetails->name); ?></td>
    </tr>
    <tr>
    	<td>Address</td>
    	<td><?php echo e($schooldetails->address); ?></td>
    </tr>
    <tr>
    	<td>City/Town</td>
    	<td><?php echo e($schooldetails->town); ?></td>
    </tr>
    <tr>
    	<td>Telephone</td>
    	<td>+<?php echo e($schooldetails->telephone); ?></td>
    </tr>
    <tr>
    	<td>Email</td>
    	<td><?php echo e($schooldetails->email); ?></td>
    </tr>
    <tr>
    	<td>Boarding</td>
    	<?php if($schooldetails->boarding == 0): ?>
    		<td>Day</td>
    	<?php elseif($schooldetails->boarding == 1): ?>
    		<td>Boarding</td>
    	<?php else: ?>
    		<td>Day and Boarding</td>
    	<?php endif; ?>
    </tr>
    <tr>
    	<td>Gender</td>
    	<?php if($schooldetails->gender == 0): ?>
    		<td>Male</td>
    	<?php elseif($schooldetails->gender == 1): ?>
    		<td>Female</td>
    	<?php else: ?>
    		<td>Mixed</td>
    	<?php endif; ?>
    </tr>

</table>
<a class="btn btn-default" href="<?php echo e(route('school.edit')); ?>">Edit Details</a>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>