<?php $__env->startSection('content'); ?>
    <h1>Reset Password</h1>
    <a href="<?php echo e(route('users.profile')); ?>" class="btn btn-success">Go Back</a>
    <?php echo Form::open(['action' => 'UsersController@resetpass', 'method' => 'POST', 'enctype' => 'multipart/form-data']); ?>

        <div class="form-group">
            <?php echo e(Form::label('curr_password', 'Current Password')); ?>

            <?php echo e(Form::password('curr_password',  ['class' => 'form-control'])); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('new_password_1', 'New Password')); ?>

            <?php echo e(Form::password('new_password_1',  ['class' => 'form-control'])); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('new_password_2', 'Confirm New Password')); ?>

            <?php echo e(Form::password('new_password_2',  ['class' => 'form-control'])); ?>

        </div>

        <?php echo e(Form::submit('Submit', ['class'=>'btn btn-primary'])); ?>

    <?php echo Form::close(); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>