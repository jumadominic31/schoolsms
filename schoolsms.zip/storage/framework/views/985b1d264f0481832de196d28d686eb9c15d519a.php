<?php $__env->startSection('content'); ?>

<h1>Attendances</h1>
<a href="<?php echo e(route('attendance.index')); ?>" class="btn btn-success">Reset</a>
<br>
<strong>Filter Options: </strong>
<input type="checkbox" autocomplete="off" onchange="checkfilter(this.checked);"/>
<div id="filteroptions" style="display: none ;">
    <?php echo Form::open(['action' => 'AttendanceController@index', 'method' => 'GET']); ?>

    <table class="table" width="100%" table-layout="fixed">
        <tbody>
            <tr>
                <td width="33.3%">
                    <div class="form-group">
                        <?php echo e(Form::label('admno', 'Admission No')); ?>

                        <?php echo e(Form::text('admno', '', ['class' => 'form-control'])); ?>

                    </div>
                </td>
                <td width="33.3%">
                    <div class="form-group">
                        <?php echo e(Form::label('student_name', 'Student Name')); ?>

                        <?php echo e(Form::text('student_name', '', ['class' => 'form-control'])); ?>

                    </div>
                </td>
                <td width="33.3%">
                    <div class="form-group">
                        <?php echo e(Form::label('checktype', 'Check IN/OUT')); ?>

                        <?php echo e(Form::select('checktype', ['' => '', 'I' => 'IN', 'O' => 'OUT'] , '', ['class' => 'form-control'])); ?>

                    </div>
                </td>
            </tr>
            <tr>
                <td >
                    <div class="form-group">
                        <?php echo e(Form::label('class_name', 'Form*')); ?>

                        <?php echo e(Form::select('class_name', ['' => '', '1' => '1', '2' => '2', '3' => '3', '4' => '4'], '', ['class' => 'form-control'])); ?>

                    </div>
                </td>
                <td >
                    <div class="form-group">
                        <?php echo e(Form::label('stream', 'Stream')); ?>

                        <?php echo e(Form::text('stream', '', ['class' => 'form-control'])); ?>

                    </div>
                </td>
                <td>
                    <div class="form-group">
                        <?php echo e(Form::label('att_date', 'Date')); ?>

                        <?php echo e(Form::text('att_date', '', ['class' => 'date form-control', 'placeholder' => 'yyyy-mm-dd'])); ?>

                    </div>
                </td>
            </tr>
        </tbody>
    </table>

    <?php echo e(Form::submit('Submit', ['class'=>'btn btn-primary', 'name' => 'submitBtn'])); ?> 
    <?php echo e(Form::submit('DownloadRpt', ['class'=>'btn btn-default', 'name' => 'submitBtn', 'formtarget' => '_blank'])); ?>

</div>

<?php echo $__env->make('attendance.attdata', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>