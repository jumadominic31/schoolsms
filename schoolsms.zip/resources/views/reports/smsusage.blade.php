@extends('layouts.app')

@section('content')

<h1>SMS Usage</h1>
<p>Summary of SMS sent: {{$sentmsgnum}} </p>
<p>SMS Balance</p>
<p>SMS Usage per day</p>
<p></p>
<p></p>
<p></p>

@endsection
