<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-8 col-md-offset-2">
        <div class="panel panel-default">
            <div class="panel-heading">Edit School Details <a 
                href="<?php echo e(route('school.index')); ?>"
                class="pull-right btn btn-default btn-xs">Go Back</a></div>

            <div class="panel-body">
              <?php echo Form::open(['action' => ['AdminController@updateschool', $school->id],'method' => 'POST']); ?>

                <div class="form-group">
                    <?php echo e(Form::label('name', 'School Name')); ?>

                    <?php if($user_id == '1'): ?>
                    <?php echo e(Form::text('name', $school->name, ['class' => 'form-control'])); ?>

                    <?php else: ?>
                    <?php echo e(Form::text('name', $school->name, ['class' => 'form-control', 'disabled' => 'true'])); ?>

                    <?php endif; ?>
                </div>
                <div class="form-group">
                    <?php echo e(Form::label('telephone', 'Phone Number')); ?>

                    <?php echo e(Form::text('telephone', $school->telephone, ['class' => 'form-control'])); ?>

                </div>
                <div class="form-group">
                    <?php echo e(Form::label('address', 'Address')); ?>

                    <?php echo e(Form::text('address', $school->address, ['class' => 'form-control'])); ?>

                </div>
                <div class="form-group">
                    <?php echo e(Form::label('town', 'Town')); ?>

                    <?php echo e(Form::text('town', $school->town, ['class' => 'form-control'])); ?>

                </div>
                <div class="form-group">
                    <?php echo e(Form::label('email', 'Email')); ?>

                    <?php echo e(Form::text('email', $school->email, ['class' => 'form-control'])); ?>

                </div>
                <div class="form-group">
                    <?php echo e(Form::label('boarding', 'Boarding')); ?>

                    <?php echo e(Form::select('boarding', ['' => '', 0 => 'Day', 1 => 'Boarding', 2 => 'Day and Boarding'], $school->boarding, ['class' => 'form-control'])); ?>

                </div>
                <div class="form-group">
                    <?php echo e(Form::label('gender', 'Gender')); ?>

                    <?php echo e(Form::select('gender', ['' => '', 0 => 'Male', 1 => 'Female', 2 => 'Mixed'], $school->gender, ['class' => 'form-control'])); ?>

                </div>
                <?php echo e(Form::hidden('_method', 'PUT')); ?>

                <?php echo e(Form::submit('Submit')); ?>

              <?php echo Form::close(); ?>

            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>