<?php $__env->startSection('content'); ?>

<h1>Students</h1>
<div class="row">
    <div class="col-md-2">
        <a href="<?php echo e(route('students.index')); ?>" class="btn btn-success" style="margin-right: 15px;">Reset</a>
    </div>
    <div class="col-md-2">
        <a href="<?php echo e(route('student.create')); ?>" class="btn btn-success" style="margin-right: 15px;">Add 1 Student</a>
    </div>
</div>
<br>
<?php echo Form::open(['action' => 'StudentController@studentsImport', 'method'=>'POST', 'files'=>'true']); ?>

<div class="row">
   <div class="col-xs-10 col-sm-10 col-md-10">
        <div class="form-group">
            <?php echo Form::label('students_file','Select File to Import:',['class'=>'col-md-3']); ?>

            <div class="col-md-9">
            <?php echo Form::file('students', ['class' => 'form-control', 'accept' => '.xls,.xlsx,.csv']); ?>

            </div>
        </div>
    </div>
    <div class="col-xs-2 col-sm-2 col-md-2 text-center">
    <?php echo Form::submit('Add Students from file',['class'=>'btn btn-success']); ?>

    </div>
</div>
<?php echo Form::close(); ?>


<br>
<h4>Filter Options: </h4>

<input type="checkbox" autocomplete="off" onchange="checkfilter(this.checked);" />

<div id="filteroptions" style="display: none ;">
    <?php echo Form::open(['action' => 'StudentController@index', 'method' => 'GET']); ?>

    <table class="table" width="100%" table-layout="fixed">
        <tbody>
            <tr>
                <td width="33.3%">
                    <div class="form-group">
                        <?php echo e(Form::label('admno', 'Admission No')); ?>

                        <?php echo e(Form::text('admno', '', ['class' => 'form-control'])); ?>

                    </div>
                </td>
                <td width="33.3%">
                    <div class="form-group">
                        <?php echo e(Form::label('student_name', 'Student Name')); ?>

                        <?php echo e(Form::text('student_name', '', ['class' => 'form-control'])); ?>

                    </div>
                </td>
                <td width="33.3%">
                    <div class="form-group">
                        <?php echo e(Form::label('parent_name', 'Parent Name')); ?>

                        <?php echo e(Form::text('parent_name', '', ['class' => 'form-control'])); ?>

                    </div>
                </td>
            </tr>
            <tr>
                <td>
                    <div class="form-group">
                        <?php echo e(Form::label('gender', 'Gender')); ?>

                        <?php echo e(Form::select('gender', ['' => '', '0' => 'Male', '1' => 'Female'], '', ['class' => 'form-control'])); ?>

                    </div>
                </td>
                <td>
                    <div class="form-group">
                        <?php echo e(Form::label('class_name', 'Form')); ?>

                        <?php echo e(Form::select('class_name', ['' => '', '1' => '1', '2' => '2', '3' => '3', '4' => '4'], '', ['class' => 'form-control'])); ?>

                    </div>
                </td>
                <td>
                    <div class="form-group">
                        <?php echo e(Form::label('stream', 'Stream')); ?>

                        <?php echo e(Form::text('stream', '', ['class' => 'form-control'])); ?>

                    </div>
                </td>
            </tr>
            <tr>
                <td>
                    <div class="form-group">
                        <?php echo e(Form::label('boarder', 'Boarder')); ?>

                        <?php echo e(Form::select('boarder', [ '' => '','1' => 'Y', '0' => 'N'], '', ['class' => 'form-control'])); ?>

                    </div>
                </td>
                <td></td>
                <td></td>
            </tr>
        </tbody>
    </table>

    <?php echo e(Form::submit('Submit', ['class'=>'btn btn-primary', 'name' => 'submitBtn'])); ?>  
    <?php echo e(Form::submit('Export_XLS', ['class'=>'btn btn-primary', 'name' => 'submitBtn', 'formtarget' => '_blank'])); ?>

</div>
<?php if(count($students) > 0): ?>
<?php
    $colcount = count($students);
    $i = 1;
?>
<table class="table table-striped" >
    <tr>
        <th></th>
        <th>Adm No</th>
        <th>Student Name</th>
        <th>Gender</th>
        <th>Parent Name</th>
        <th>Phone</th>
        <th>Form</th>
        <th>Stream</th>
        <th>Boarder</th>
        <th></th>
    </tr>
    <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><?php echo e($index + 1); ?></td>
        <td><?php echo e($student['Admno']); ?></td>
        <td><?php echo e($student['NAME']); ?></td>
        <td><?php echo e($student['GENDER']); ?></td>
        <td><?php echo e($student['ParentName']); ?></td>
        <td><?php echo e($student['OPHONE']); ?></td>
        <td><?php echo e($student['Class']); ?></td>
        <td><?php echo e($student['Stream']); ?></td>
        <td><?php echo e($student['boarder']); ?></td>
        <td><span class="center-block"><a class="pull-right btn btn-default" href="<?php echo e(route('student.edit', ['student' => $student->Admno ])); ?>">Edit</a></span></td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
<?php echo e($students->appends(request()->input())->links()); ?>

<?php else: ?>
    <p>No Students To Display</p>
<?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>