@extends('layouts.app')

@section('content')

<h1>Group Attendance</h1>
<p>Summary of SMS sent: {{$sentmsgnum}} </p>

<p></p>
<p></p>

@endsection
