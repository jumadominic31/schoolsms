<br><br>
<?php if(count($attendances) > 0): ?>
<?php
    $colcount = count($attendances);
    $i = 1;
?>
<table class="table table-striped" >
    <tr>
        <th></th>
        <th>Student</th>
        <th>Adm No</th> 
        <th>Form</th>
        <th>Time</th> 
        <th>Check In/Out</th>        
    <?php $__currentLoopData = $attendances; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $attendance): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><?php echo e($index + 1); ?></td>
        <td><?php echo e($attendance['NAME']); ?></td>
        <td><?php echo e($attendance['Admno']); ?></td>
        <td><?php echo e($attendance['Class']); ?> <?php echo e($attendance['Stream']); ?></td>
        <td><?php echo e($attendance['CHECKTIME']); ?></td>
        <td><?php echo e($attendance['CHECKTYPE']); ?></td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
<?php else: ?>
    <p>No Check in/out To Display</p>
<?php endif; ?>