<?php $__env->startSection('content'); ?>

<h1>Portal Users Administration </h1>

<a href="<?php echo e(route('users.create')); ?>" class="btn btn-success">Add User</a>
<br>
    <?php if(count($users) > 0): ?>
        <?php
            $colcount = count($users);
            $i = 1;
        ?>
        
        <table class="table table-striped" >
            <tr>
                <th>User Name</th>
                <th>Full Name</th>
                <th>Telephone</th>
                <th>Email</th>
                <th>Status</th>
                <th></th>
            </tr>
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($user['username']); ?></td>
                <td><?php echo e($user['name']); ?></td>
                <td><?php echo e($user['telephone']); ?></td>
                <td><?php echo e($user['email']); ?></td>
                <td><?php if ($user['status'] == 1 ) {echo "Active";} else {echo "Inactive";} ?></td>
                <td><a class="btn btn-default btn-xs" href="<?php echo e(route('users.edit', ['user' => $user->id ])); ?>">Edit</a></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
        <?php echo e($users->links()); ?>

    <?php else: ?>
      <p>No users To Display</p>
    <?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>