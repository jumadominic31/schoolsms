<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class StatusReason extends Model
{
    //
}
