<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-8 col-md-offset-2">
        <div class="panel panel-default">
            <div class="panel-heading">Add Student <a href="<?php echo e(route('students.index')); ?>" 
                class="pull-right btn btn-default btn-xs">Go Back</a></div>

            <div class="panel-body">
                <?php echo Form::open(['action' => ['StudentController@store'],'method' => 'POST']); ?>

                    <div class="form-group">
                        <?php echo e(Form::label('admno', 'Admission Number *')); ?>

                        <?php echo e(Form::text('admno', '', ['class' => 'form-control', 'placeholder' => ''])); ?>

                    </div>
                    <div class="form-group">
                        <?php echo e(Form::label('name', 'Student Name *')); ?>

                        <?php echo e(Form::text('name', '', ['class' => 'form-control', 'placeholder' => ''])); ?>

                    </div>
                    <div class="form-group">
                        <?php echo e(Form::label('gender', 'Gender *')); ?>

                        <?php echo e(Form::select('gender', ['' => '', 0 => 'Male', 1 => 'Female'], 0, ['class' => 'form-control'])); ?>

                    </div>
                    <div class="form-group">
                        <?php echo e(Form::label('parent_name', 'Parent Name')); ?>

                        <?php echo e(Form::text('parent_name', '', ['class' => 'form-control', 'placeholder' => ''])); ?>

                    </div>
                    <div class="form-group">
                        <?php echo e(Form::label('phone', 'Parent Phone *')); ?>

                        <?php echo e(Form::text('phone', '', ['class' => 'form-control', 'placeholder' => '254722000000'])); ?>

                    </div>
                    <div class="form-group">
                        <?php echo e(Form::label('class_name', 'Class/Form *')); ?>

                        <?php echo e(Form::select('class_name', ['' => '', '1' => '1', '2' => '2', '3' => '3', '4' => '4'], '1', ['class' => 'form-control'])); ?>

                    </div>
                    <div class="form-group">
                        <?php echo e(Form::label('stream', 'Stream *')); ?>

                        <?php echo e(Form::text('stream', '', ['class' => 'form-control', 'placeholder' => ''])); ?>

                    </div>
                    <div class="form-group">
                        <?php echo e(Form::label('boarder', 'Boarder *')); ?>

                        <?php echo e(Form::select('boarder', ['1' => 'Boarder', '0' => 'Day Scholar'], '1', ['class' => 'form-control', 'placeholder' => ''])); ?>

                    </div>
                <?php echo e(Form::submit('Submit', ['class'=>'btn btn-primary'])); ?>

                <?php echo Form::close(); ?>

            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>