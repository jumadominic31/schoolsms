<?php $__env->startSection('content'); ?>
    <h1>Create User</h1>
    <a href="<?php echo e(route('users.index')); ?>" class="pull-right btn btn-default">Go Back</a>
	<br>
    <?php echo Form::open(['action' => 'UsersController@store', 'method' => 'POST', 'enctype' => 'multipart/form-data']); ?>

        <div class="form-group">
            <?php echo e(Form::label('username', 'Username')); ?>

            <?php echo e(Form::text('username', '', ['class' => 'form-control', 'placeholder' => 'Username'])); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('name', 'Name')); ?>

            <?php echo e(Form::text('name', '', ['class' => 'form-control', 'placeholder' => 'Name'])); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('pass1', 'Password *')); ?>

            <?php echo e(Form::password('pass1',  ['class' => 'form-control'])); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('pass2', 'Password Again *')); ?>

            <?php echo e(Form::password('pass2',  ['class' => 'form-control'])); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('telephone', 'Telephone Number')); ?>

            <?php echo e(Form::text('telephone', '', ['class' => 'form-control', 'placeholder' => 'Format example 254722000000'])); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('email', 'Email')); ?>

            <?php echo e(Form::text('email', '', ['class' => 'form-control', 'placeholder' => 'Email Address'])); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('status', 'Status')); ?>

            <?php echo e(Form::select('status', ['' => '', 1 => 'Active', 0 => 'Inactive'], 1, ['class' => 'form-control'])); ?>

        </div>
        <?php echo e(Form::submit('Submit', ['class'=>'btn btn-primary'])); ?>

    <?php echo Form::close(); ?>

    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>