<?php $__env->startSection('content'); ?>

<h1>SMS Engine Setup</h1>
<?php echo Form::open(['action' => ['AdminController@updatesmseng'],'method' => 'POST']); ?>

<table class="table" width="100%" table-layout="fixed">
    <tbody>
    	<tr>
            <td>
                <div class="form-group">
                    <?php echo e(Form::label('school_name', 'School Name')); ?>

                    <?php echo e(Form::text('school_name', $school_name, ['class' => 'form-control', 'disabled' => 'true'])); ?>

                </div>
            </td>
        </tr>
        <tr>
            <td>
                <div class="form-group">
                    <?php echo e(Form::label('atgusername', 'Username')); ?>

                    <?php echo e(Form::text('atgusername', $apidetails->atgusername, ['class' => 'form-control'])); ?>

                </div>
            </td>
        </tr>
        <tr>
            <td >
                <div class="form-group">
                    <?php echo e(Form::label('atgapikey', 'API Key')); ?>

                    <?php echo e(Form::text('atgapikey', $apidetails->atgapikey, ['class' => 'form-control'])); ?>

                </div>
            </td>
        </tr>
        <tr>
            <td >
                <div class="form-group">
                    <?php echo e(Form::label('atgsender_id', 'Sender ID')); ?>

                    <?php echo e(Form::text('atgsender_id', $apidetails->atgsender_id, ['class' => 'form-control'])); ?>

                </div>
            </td>
        </tr>
    </tbody>
</table>
<?php echo e(Form::hidden('_method', 'PUT')); ?>

<?php echo e(Form::submit('Submit', ['class'=>'btn btn-primary'])); ?>

<?php echo Form::close(); ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>