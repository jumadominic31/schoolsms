<!DOCTYPE html>
<html>
<head>

	<title>Attendance Report</title>
	<style>
	    @page  { margin: 100px 25px; font-family:  Helvetica, Arial, sans-serif;}
	    header { position: fixed; top: -60px; left: 0px; right: 0px; background-color: lightblue; height: 60px; }
	    footer { position: fixed; bottom: -60px; left: 0px; right: 0px; background-color: lightblue; height: 50px; }
	    p { page-break-after: always; }
	    p:last-child { page-break-after: never; }
      table { border-collapse: collapse;  width: 100%; font-size: 12px;}
      table, th, td { border: 1px solid black; }
	  </style>
</head>
<body>
	<header style="text-align: center"><?php echo e($sch_details['name']); ?> <br> <?php echo e($sch_details['address']); ?>, <?php echo e($sch_details['town']); ?> <br> Phone: <?php echo e($sch_details['telephone']); ?></header>
    <footer style="text-align: right">Powered by QBS - info@quadcorn.co.ke</footer>

    <div style="text-align: center"><h2>Attendance Report</h2></div>
    Print Date:  <?php echo e(date('d-m-Y', strtotime($curr_date))); ?><br><br>
    Form: <?php echo e($choices['class']); ?><br>
    Stream: <?php echo e($choices['stream']); ?><br>
    Attendance Date: <?php echo e(date('d-m-Y', strtotime($choices['att_date']))); ?><br>
    Check In/Out: <?php echo e($choices['checktype']); ?><br>

	<?php echo $__env->make('attendance.attdata', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

</body>
</html>