<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SmsApi extends Model
{
    //
}
